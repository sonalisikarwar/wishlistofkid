import { getFakeI18NData } from "../services/getFakeAPIData";
export function i18n(str) {
  return getFakeI18NData()[str];
}
