export function getFakeAPIData() {
  return {
    wishList: [
      {
        id: "a1",
        description: "handheld gaming console nds/gba psp ",
        link: "https://something.com/psp"
      },
      {
        id: "a2",
        description: "pokemon database device",
        link: "https://soemthing.com/pokemon"
      }
    ]
  };
}

export function getFakeI18NData() {
  return {
    mainHeader: "fulfil a wish",
    subHeader: "shaurya king's wishlist"
  };
}
